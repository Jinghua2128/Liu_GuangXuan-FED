function Singer(name, specialty, power, hitpoints, level, gender) {
    this.name = name;
    this.specialty = specialty;
    this.power = power;
    this.hitpoints = hitpoints;
    this.level = level;
    this.gender = gender;

    this.singerProfile = function () {
        let hpStatus;
        if (this.hitpoints <= 50) {
            hpStatus = "Weak!";
        } else if (this.hitpoints > 50 && this.hitpoints < 71) {
            hpStatus = "Strong";
        } else {
            hpStatus = "Amazing";
        }
        return `${this.name} Level ${this.level}, gender ${this.gender}, specialty ${this.specialty}, power ${this.power}, <br> Hitpoints: ${hpStatus}`;
    };
}

// Create the function objects momobae and minabae.
let momobae = new Singer('Momobae', 'Dance', 49, 50, 15, 'female');
let minabae = new Singer('Minabae', 'Sleeping', 80, 100, 10, 'female');

let singers = [momobae, minabae];

let profiles = [];

for (let i = 0; i < singers.length; i++) {
    profiles.push(singers[i].singerProfile());
}

// Log the profiles array to verify
console.log(profiles);


// Create a new element for Momobae's profile
let newDiv1 = document.createElement("div");
// Add class to element
newDiv1.classList.add("mystyle");
// Add content
newDiv1.innerHTML = "Momobae's Singer Profile: <br>" + momobae.singerProfile();
// Append the div to the body
document.body.appendChild(newDiv1);

// Create a new element for Minabae's profile
let newDiv2 = document.createElement("div");
// Add class to element
newDiv2.classList.add("mystyle");
// Add content
newDiv2.innerHTML = "Minabae's Singer Profile: <br>" + minabae.singerProfile();
// Append the div to the body
document.body.appendChild(newDiv2);