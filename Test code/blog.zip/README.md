# Liu_GuangXuan-FED

This project was created as part of the Front-End Development module at Ngee Ann Polytechnic. The focus of this project is to apply Front-End development concepts and build a functional and engaging application.